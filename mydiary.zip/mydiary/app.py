from flask import Flask,render_template,request,redirect
import mysql.connector
app = Flask(__name__)

@app.route("/")
def index():
    return render_template('index.html')

@app.route("/myentries")
def myentries():
    return render_template('myentries.html')

@app.route("/dashboard")
def dashboard():
    try:
        conn=mysql.connector.connect(db="mydiary",user="root",password="skillverse")
        curs=conn.cursor()
        username=request.form.get('username')
        password=request.form.get('password')
        getentries="SELECT * FROM entries limit 0, 10"
        print("running",getentries)
        curs.execute(getentries)
        entries=curs.fetchall()
        return render_template('dashboard.html',result=entries)
    except mysql.connector.Error as e:
            print(e.msg)
            return
    return render_template('dashboard.html')

@app.route("/logout")
def logout():
    return render_template('logout.html')

@app.route("/addentry")
def addentry():
    return render_template('addentry.html')

@app.route("/login",methods=['GET'])
def loginfailed():
    return render_template('index.html')
    
@app.route("/showentry/<entry_id>",methods=['GET'])
def showentry(entry_id):
    try:
        conn=mysql.connector.connect(db="mydiary",user="root",password="skillverse")
        curs=conn.cursor()
        username=request.form.get('username')
        password=request.form.get('password')
        getentry="SELECT * FROM entries where id="+entry_id
        print("running",getentry)
        curs.execute(getentry)
        entry=curs.fetchall()
        return render_template('showentry.html',entry=entry)
    except mysql.connector.Error as e:
        print(e.msg)
        return
    
@app.route("/dologin",methods=['POST'])
def login():
    try:
        conn=mysql.connector.connect(db="mydiary",user="root",password="skillverse")
        curs=conn.cursor()
        username=request.form.get('username')
        password=request.form.get('password')
        checkuser="select count(username) as userexists from users where username='"+username+"' and password='"+password+"'"
        print("running",checkuser)
        curs.execute(checkuser)
        for userexists in curs:
            print("userexists:",userexists[0])
            if(userexists[0]==1):
                curs.close()
                conn.close()
                return render_template('dashboard.html')
            else:
                return redirect('/')
         
    except mysql.connector.Error as e:
        print(e.msg)
    return
    
@app.route("/editentry/<entry_id>")
def editentry(entry_id):
    try:
        conn=mysql.connector.connect(db="mydiary",user="root",password="skillverse")
        curs=conn.cursor()
        username=request.form.get('username')
        password=request.form.get('password')
        getentry="SELECT * FROM entries where id="+entry_id
        print("running",getentry)
        curs.execute(getentry)
        entry=curs.fetchall()
        return render_template('editentry.html',entry=entry)
    except mysql.connector.Error as e:
        print(e.msg)




@app.route("/register")
def registerform():
    return render_template('register.html')

@app.route("/registeruser",methods=['POST'])
def register():
    try:
        conn=mysql.connector.connect(db="mydiary",user="root",password="skillverse")
        curs=conn.cursor()
        username=request.form.get('username')
        password=request.form.get('password')
        email=request.form.get('email')
        phone=request.form.get('phone')
        createuser="insert into users(username,email,password,phone) values('"+username+"','"+email+"','"+password+"','"+phone+"')"
        print("running",createuser)
        curs.execute(createuser)
        conn.commit()
        curs.close()
        conn.close()
    except mysql.connector.Error as e:
        print(e.msg)
    return render_template('registersuccess.html')

@app.route("/storeentry",methods=['POST'])
def storeentry():
    try:
        conn=mysql.connector.connect(db="mydiary",user="root",password="skillverse")
        curs=conn.cursor()
        date=request.form.get('date')
        entry=request.form.get('entry')
        title=request.form.get('entry')
        insertentry="insert into entries(date,title,entry) values('"+date+"','"+entry+"','"+title+"')"
        print("adding entry",insertentry)
        curs.execute(insertentry)
        conn.commit()
        curs.close()
        conn.close()
        return redirect('/dashboard')
    except mysql.connector.Error as e:
        print(e.msg)

@app.route("/updateentry",methods=['POST'])
def updateentry():
    try:
        conn=mysql.connector.connect(db="mydiary",user="root",password="skillverse")
        curs=conn.cursor()
        entry_id=request.form.get('entry_id')
        date=request.form.get('date')
        entry=request.form.get('entry')
        title=request.form.get('entry')
        updateentry="update entries set date='"+date+"' , entry='"+entry+"' , title='"+title+"' where id="+entry_id
        print("adding entry",updateentry)
        curs.execute(updateentry)
        conn.commit()
        curs.close()
        conn.close()
        return redirect('/dashboard')
    except mysql.connector.Error as e:
        print(e.msg)

